
export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const { prompt } = await req.json();

  const response = await fetch("https://api.replicate.com/v1/predictions", {
    method: "POST",
    headers: {
      Authorization: `Token ${process.env.REPLICATE_API_TOKEN}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      version: "db21e45e40cf26e4ff3d52f18c1e9f34670f2e5c7683ab9da6fb8b9310fab217",
      input: { prompt },
    }),
  });

  const prediction = await response.json();
  const image = prediction?.output?.[0];

  return Response.json({ image });
}
