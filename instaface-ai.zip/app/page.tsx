
"use client";
import { useState } from "react";

export default function Home() {
  const [input, setInput] = useState("");
  const [image, setImage] = useState("");
  const [loading, setLoading] = useState(false);

  const generateImage = async () => {
    setLoading(true);
    setImage("");

    const response = await fetch("/api/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt: input }),
    });

    const data = await response.json();
    setImage(data.image);
    setLoading(false);
  };

  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-gray-100 p-4">
      <h1 className="text-3xl font-bold mb-4">InstaFace - AI Photo Generator</h1>
      <input
        type="text"
        className="w-full max-w-md p-2 border border-gray-300 rounded mb-4"
        placeholder="Describe your image..."
        value={input}
        onChange={(e) => setInput(e.target.value)}
      />
      <button
        onClick={generateImage}
        disabled={loading}
        className="bg-blue-500 text-white px-4 py-2 rounded"
      >
        {loading ? "Generating..." : "Generate Image"}
      </button>

      {image && (
        <div className="mt-6">
          <img src={image} alt="Generated" className="rounded shadow-md" />
        </div>
      )}
    </main>
  );
}
