# InstaFace AI
A simple Text-to-Image generator using Replicate API (Stable Diffusion) and Next.js.